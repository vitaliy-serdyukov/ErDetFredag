package com.example.erdetfredag.services;
import java.time.LocalDate;


public class DayWeekCalculator {

  private final LocalDate today = LocalDate.now();
  private int q; // day of the month
  private int m; // month number
  private int j; // century
  private int k; // year of the century

  private int tempVar; // temporary variable
  private int dayOfWeek;// day of the week




  public LocalDate getToday() {
    return today;
  }


  public void getDay (){
    q = today.getDayOfMonth();
  }

  public void getMonth (){
    m = today.getMonthValue();
  }

  public void getCentury (){
    j = (today.getYear() / 100);
  }

  public void getYearOfCentury (){
    k = (today.getYear() % 100);
  }

  public void calculateTempVar(){
    tempVar = (q + (13 * (m + 1)) / 5 + k + (k / 4) + (j / 4) - 2 * j) % 7;
  }

  public int calculateDayOfWeek(){ // to do! this formula doesn't work for me..why?
    dayOfWeek = ((tempVar + 5) % 7) + 1;
    return dayOfWeek;
  }


  public boolean isFriday(){
    if (dayOfWeek == 5) {
      return true;
    } else
      return false;
    }

}
