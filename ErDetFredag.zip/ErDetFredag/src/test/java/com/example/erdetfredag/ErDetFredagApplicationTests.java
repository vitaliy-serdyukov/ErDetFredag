package com.example.erdetfredag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErDetFredagApplicationTests {

  @Test
  void contextLoads() {
  }

}
